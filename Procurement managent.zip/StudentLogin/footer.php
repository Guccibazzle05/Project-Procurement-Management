    </div> <!-- Close container div -->

    <footer>
        <p>&copy; <?php echo date('Y'); ?> Study Planner. All rights reserved.</p>
    </footer>
</body>
</html>